import os

from dassl.data.datasets import DATASET_REGISTRY, Datum, DatasetBase
from dassl.utils import listdir_nohidden ,mkdir_if_missing
import pickle
from .imagenet import ImageNet
from .oxford_pets import OxfordPets
import numpy as np
TO_BE_IGNORED = ["README.txt"]

@DATASET_REGISTRY.register()
class UCF101(DatasetBase):


    dataset_dir = "ucf101"

    def __init__(self, cfg ):
        root = os.path.abspath(os.path.expanduser(cfg.DATASET.ROOT)) # ./data
        self.dataset_dir = os.path.join(root, self.dataset_dir) # ./data/ucf101
        self.image_dir = os.path.join(self.dataset_dir, "ucf") # ./data/ucf101/ucf
        self.preprocessed = os.path.join(self.dataset_dir, "preprocessed.pkl")
        self.split_fewshot_dir = os.path.join(self.dataset_dir, "split_fewshot")
        mkdir_if_missing(self.split_fewshot_dir)

        self.class_order = np.arange(100).tolist()
        
        if os.path.exists(self.preprocessed):
            with open(self.preprocessed, "rb") as f:
                preprocessed = pickle.load(f)
                train = preprocessed["train"]
                test = preprocessed["test"]
        else:
            text_file = os.path.join(self.dataset_dir, "classnames.txt") # 类名信息
            classnames = ImageNet.read_classnames(text_file) # 类标签 和 类名 字典
            print(classnames)
            print()
            train = self.read_data(classnames, "train") # Datum 对象列表
            # Follow standard practice to perform evaluation on the val set
            # Also used as the val set (so evaluate the last-step model)
            test = self.read_data(classnames, "test")  # Datum 对象列表

            preprocessed = {"train": train, "test": test}
            with open(self.preprocessed, "wb") as f:
                pickle.dump(preprocessed, f, protocol=pickle.HIGHEST_PROTOCOL)
        # preprocessed = {"train": train, "test": test} 存储训练数据和测试数据
        num_shots = cfg.DATASET.NUM_SHOTS
        if num_shots >= 1:
            seed = cfg.SEED
            preprocessed = os.path.join(self.split_fewshot_dir, f"shot_{num_shots}-seed_{seed}.pkl")
            
            if os.path.exists(preprocessed):
                print(f"Loading preprocessed few-shot data from {preprocessed}")
                with open(preprocessed, "rb") as file:
                    data = pickle.load(file)
                    train = data["train"]
            else:
                train = self.generate_fewshot_dataset(train, num_shots=num_shots)
                data = {"train": train}
                print(f"Saving preprocessed few-shot data to {preprocessed}")
                with open(preprocessed, "wb") as file:
                    pickle.dump(data, file, protocol=pickle.HIGHEST_PROTOCOL)
            
        subsample = cfg.DATASET.SUBSAMPLE_CLASSES
        train, test = OxfordPets.subsample_classes(train, test, subsample=subsample)
        print("train:" ,  len(train) , " " , "test:" ,len(test))
        super().__init__(train_x=train, val=test, test=test)

    def read_data(self, classnames , split_dir):
        split_dir = os.path.join(self.image_dir, split_dir)
        folders = listdir_nohidden(split_dir, sort=True)
        folders = [f for f in folders if f not in TO_BE_IGNORED]
        items = []

        for label, folder in enumerate(folders):
            imnames = listdir_nohidden(os.path.join(split_dir, folder))
            print(folder)
            classname = classnames[folder]
            for imname in imnames:
                impath = os.path.join(split_dir, folder, imname)
                item = Datum(impath=impath, label=label, classname=classname)
                items.append(item)

        return items
