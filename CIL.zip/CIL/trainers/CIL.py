import os.path as osp
import os
import torch
from torch.autograd import Variable
import torch.nn as nn
from torch.nn import functional as F
from torch.cuda.amp import GradScaler, autocast
from torch.utils.data import DataLoader
import copy
import numpy as np

from dassl.engine import TRAINER_REGISTRY, TrainerX
from dassl.metrics import compute_accuracy
from dassl.utils import load_pretrained_weights, load_checkpoint
from dassl.optim import build_optimizer, build_lr_scheduler
from dassl.data.samplers import build_sampler 
from dassl.data.data_manager import DatasetWrapper ,DataManager_incremental
from dassl.engine import build_trainer
from clip import clip
from clip.simple_tokenizer import SimpleTokenizer as _Tokenizer

from loralib.utils import mark_only_lora_as_trainable, apply_lora, get_lora_parameters, lora_state_dict, save_lora, load_lora



_tokenizer = _Tokenizer()
# os.environ["CUDA_VISIBLE_DEVICES"] = "0"
batch_size = 128
EPSILON = 1e-8

CUSTOM_TEMPLATES = {
    "cub" : "a photo of a {}, a type of bird.",
    "cars" :  "a photo of a {}.",
    "aircraft" : "a photo of a {}, a type of aircraft.",
    "cifar224":"a photo of a {}." ,
    "OxfordPets": "a photo of a {}, a type of pet.",
    "OxfordFlowers": "a photo of a {}, a type of flower.",
    "FGVCAircraft": "a photo of a {}, a type of aircraft.",
    "DescribableTextures": "{} texture.",
    "EuroSAT": "a centered satellite photo of {}.",
    "StanfordCars": "a photo of a {}.",
    "Food101": "a photo of {}, a type of food.",
    "SUN397": "a photo of a {}.",
    "Caltech101": "a photo of a {}.",
    "UCF101": "a photo of a person doing {}.",
    "ImageNet": "a photo of a {}.",
    "ImageNetSketch": "a photo of a {}.",
    "ImageNetV2": "a photo of a {}.",
    "ImageNetA": "a photo of a {}.",
    "ImageNetR": "a photo of a {}.",
}


def tensor2numpy(x):
    return x.cpu().data.numpy() if x.is_cuda else x.data.numpy()
def load_clip_to_cpu(cfg):
    backbone_name = cfg.MODEL.BACKBONE.NAME
    url = clip._MODELS[backbone_name]
    model_path = clip._download(url)
    
    try:
        # loading JIT archive
        model = torch.jit.load(model_path, map_location="cpu").eval()
        state_dict = None

    except RuntimeError:
        state_dict = torch.load(model_path, map_location="cpu")

    model = clip.build_model(state_dict or model.state_dict())

    return model

def build_data_loader(
    cfg,
    sampler_type="SequentialSampler",
    data_source=None,
    batch_size=64,
    n_domain=0,
    n_ins=2,
    tfm=None,
    is_train=True,
    dataset_wrapper=None
):
    # Build sampler
    sampler = build_sampler(
        sampler_type,
        cfg=cfg,
        data_source=data_source,
        batch_size=batch_size,
        n_domain=n_domain,
        n_ins=n_ins
    )

    if dataset_wrapper is None:
        dataset_wrapper = DatasetWrapper

    # Build data loader
    data_loader = torch.utils.data.DataLoader(
        dataset_wrapper(cfg, data_source, transform=tfm, is_train=is_train),
        batch_size=batch_size,
        sampler=sampler,
        num_workers=cfg.DATALOADER.NUM_WORKERS,
        drop_last=is_train and len(data_source) >= batch_size,
        pin_memory=(torch.cuda.is_available() and cfg.USE_CUDA)
    )
    assert len(data_loader) > 0

    return data_loader


class TextEncoder(nn.Module):
    def __init__(self, clip_model):
        super().__init__()
        self.transformer = clip_model.transformer
        self.positional_embedding = clip_model.positional_embedding
        self.ln_final = clip_model.ln_final
        self.text_projection = clip_model.text_projection
        self.dtype = clip_model.dtype

    def forward(self, prompts, tokenized_prompts):
        
        x = prompts + self.positional_embedding.type(self.dtype)
        x = x.permute(1, 0, 2)  # NLD -> LND
        x = self.transformer(x)
        x = x.permute(1, 0, 2)  # LND -> NLD
        x = self.ln_final(x).type(self.dtype)

        # x.shape = [batch_size, n_ctx, transformer.width]
        # take features from the eot embedding (eot_token is the highest number in each sequence)
        x = x[torch.arange(x.shape[0]), tokenized_prompts.argmax(dim=-1)] @ self.text_projection

        return x

class Prompt(nn.Module):
    def __init__(self, cfg, classnames, clip_model,device ):
        super().__init__()
        self.cfg = cfg
        self.dtype = clip_model.dtype
        temp = CUSTOM_TEMPLATES[cfg.DATASET.NAME]
        print(f'template: "{temp}"')

        prompts = [temp.format(c.replace("_", " ")) for c in classnames]
        self.prompts = torch.cat([clip.tokenize(p) for p in prompts])
        
        self.prompts = self.prompts.to(device)
        with torch.no_grad():
            
            text_features = clip_model.encode_text( self.prompts)
            text_features = text_features / text_features.norm(dim=-1, keepdim=True)

        self.text_features = text_features
        
    def forward(self ):
        return self.text_features



    
class CustomCLIP(nn.Module):
    def __init__(self, cfg, classnames, clip_model , device ,mode = "train"):
        super().__init__()
        
        self.prompt_learner = Prompt(cfg, classnames, clip_model ,device)
        # self.tokenized_prompts = self.prompt_learner.tokenized_prompts
        self.image_encoder = clip_model.visual
        # self.text_encoder = TextEncoder(clip_model)
        self.logit_scale = clip_model.logit_scale
        self.dtype = clip_model.dtype
        self.projs_img =  nn.ModuleList()
        self._device = torch.device(device)

    def forward(self, image):
        image_features = self.image_encoder(image.type(self.dtype))
        text_features = self.prompt_learner()
       
        image_features = image_features / image_features.norm(dim=-1, keepdim=True)

        logit_scale = self.logit_scale.exp()
        logits = logit_scale * image_features @ text_features.t()
        return logits



@TRAINER_REGISTRY.register()
class CIL(TrainerX):
    
    def __init__(self, cfg):
        self.data_manager = DataManager_incremental(cfg , shuffle = True , seed = 1993)
        super().__init__(cfg)
        self._cur_task = -1
        self._known_classes = 0
        self._total_classes = 0
        self.cfg = cfg
        self._fixed_memory = False
        self._data_memory, self._targets_memory = np.array([]), np.array([])
        self.feature_dim = 512
        self._memory_size = 4000
        self.task_id = 0
        self.img_prototypes = None
        self._device = "cuda:0"
        self.log = open('/root/autodl-tmp/code/code/CIL/output/cars/CIL/vit_b16_0shots/car_task40_time.txt','w') 


    def after_task(self):
        self._known_classes = self._total_classes

    def incremental_train(self , start_class , end_class  ,k , criterion  , mode ="train"):
        data_manager = self.data_manager
        self._cur_task += 1
        self.cls_num_list = []

        
        self._total_classes = self._known_classes + data_manager.get_task_size(self._cur_task) # 目前为止已见类
        train_num = self.samples_per_class
   
        
        print("Learning on {}-{}".format(self._known_classes, self._total_classes))
        cfg = self.cfg
        train_dataset , train_target = data_manager.get_dataset(np.arange(start_class, end_class),source="train", mode="train",train_num = 0,
                                                     appendent=self._get_memory()
                                                     ) 
        print(train_target)
        for i in range(0 , end_class):
            self.cls_num_list.append(np.sum(train_target==i))
        print("cls_num_list:" , self.cls_num_list)
        

        from torchvision import transforms

        self.train_dataset = train_dataset
        self.data_manager = data_manager
        self.train_loader = build_data_loader(cfg,
                            sampler_type=cfg.DATALOADER.TRAIN_X.SAMPLER, # 采样类型  train : RandomSampler  test : SequentialSampler
                            data_source=train_dataset,
                            batch_size= 32 , # cfg.DATALOADER.TRAIN_X.BATCH_SIZE, # train : 32 test : 100
                            n_domain=cfg.DATALOADER.TRAIN_X.N_DOMAIN,
                            n_ins=cfg.DATALOADER.TRAIN_X.N_INS,
                            tfm= data_manager.tfm_train,
                            is_train=True,
                            dataset_wrapper=self.data_manager.dataset_wrapper)
        # 测试训练时要修改
        if mode == "train":
            start_class_test = start_class
        else:
            start_class_test = 0

        test_dataset , _ = data_manager.get_dataset(np.arange(0, end_class), source="test", mode="test" )
        self.test_dataset = test_dataset
        self.test_loader = build_data_loader(cfg,
                            sampler_type=cfg.DATALOADER.TEST.SAMPLER, # 采样类型  train : RandomSampler  test : SequentialSampler
                            data_source=test_dataset,
                            batch_size=cfg.DATALOADER.TEST.BATCH_SIZE, # train : 32 test : 100
                            tfm=data_manager.tfm_test,
                            is_train=False,
                            dataset_wrapper=self.data_manager.dataset_wrapper)

        # 目前已见的所有类别
        test_dataset_all , _ = data_manager.get_dataset(np.arange(0, end_class), source="test", mode="test" )
        self.test_loader_all = build_data_loader(cfg,
                            sampler_type=cfg.DATALOADER.TEST.SAMPLER, # 采样类型  train : RandomSampler  test : SequentialSampler
                            data_source=test_dataset_all,
                            batch_size=cfg.DATALOADER.TEST.BATCH_SIZE, # train : 32 test : 100
                            tfm=data_manager.tfm_test,
                            is_train=False,
                            dataset_wrapper=self.data_manager.dataset_wrapper)
        if mode == "train":
            self.max_epoch = 20
            self.train_incremental(k ,criterion , train_phase = "second")
            self.after_task()

    def train_incremental(self ,k , criterion ,train_phase):
        """Generic training loops."""
        
        lambda_0 = 0.5
        self.before_train(train_phase) # 训练前的准备工作
        for self.epoch in range(self.start_epoch, self.max_epoch):

            ratio = lambda_0 * (self.epoch / self.max_epoch)
            self.before_epoch() # 函数体是 pass ，相当于不运行任何操作
            self.run_epoch_incremental(k ,criterion , ratio , train_phase )
            self.after_epoch() # 运行的是 SimpleTrainer 类的 函数
        self.after_train(train_phase)

        if train_phase == "second":
            self.build_memory(self.data_manager, self.samples_per_class)
    

    def build_memory(self , data_manager , per_class):
        
        self._reduce_exemplar(data_manager ,per_class)
        self._construct_exemplar(data_manager, per_class)
        

    @property
    def samples_per_class(self):
        if self._fixed_memory:
            return self._memory_per_class
        else:
            assert self._total_classes != 0, "Total classes is 0"
            return self._memory_size // self._total_classes

    def check_cfg(self, cfg):
        assert cfg.TRAINER.CIL.PREC in ["fp16", "fp32", "amp"]

    def get_classname(self , data):
        out = []
        for i in data:
            if len(out) == 0 or i.classname not in out:
                out.append(i.classname)
        return out

    def build_model(self ):
        cfg = self.cfg

        # classnames = self.dm.dataset.classnames
        
        print(f"Loading CLIP (backbone: {cfg.MODEL.BACKBONE.NAME})")

        self.clip_model = load_clip_to_cpu(cfg)
        
        if cfg.TRAINER.CIL.PREC == "fp32" or cfg.TRAINER.CIL.PREC == "amp":
            # CLIP's default precision is fp16
            self.clip_model.float()
        self.clip_model.float()
        print("Building custom CLIP")
        # 每次任务中的类名
        self.encode_image = self.clip_model.visual
        print("No Apply LoRA")
        list_lora_layers = apply_lora(encoder = 'both', position = 'all' , params = ['q', 'k', 'v' ] , r = 2 , alpha = 1 ,
                                          dropout_rate = 0.25 , backbone = 'ViT-B/16' , clip_model = self.clip_model)
        print(self.device)
        self.clip_model.to(self.device)

        temp , _ = self.data_manager.get_dataset(np.arange(cfg.DATASET.START_CLASS, cfg.DATASET.END_CLASS), train_num = 4000 ,source="train", mode="train" )
        classnames = self.get_classname(temp)
        
        self.model = CustomCLIP(cfg, classnames, self.clip_model , self.device)
        
        print("Turning off gradients in both the image and the text encoder")
        for name, param in self.model.named_parameters():
            if "prompt_learner" not in name :
                param.requires_grad_(False)
            if 'lora_'  in name:
                param.requires_grad_(True)
            if 'featurefusion' in name:
                param.requires_grad_(True)
        
        if cfg.MODEL.INIT_WEIGHTS:
            load_pretrained_weights(self.model.prompt_learner, cfg.MODEL.INIT_WEIGHTS)

        self.model.to(self.device)

        self.scaler = GradScaler() if cfg.TRAINER.CIL.PREC == "amp" else None
        # Note that multi-gpu training could be slow because CLIP's size is
        # big, which slows down the copy operation in DataParallel
        device_count = torch.cuda.device_count()


    def forward_backward(self, batch ,k ,  criterion , ratio , train_phase ):
        image, label = self.parse_batch_train(batch)
        
        prec = self.cfg.TRAINER.CIL.PREC
        if prec == "amp":
            with autocast():
                output = self.model(image , train_phase)
                loss = F.cross_entropy(output, label)
            self.optim.zero_grad()
            self.scaler.scale(loss).backward()
            self.scaler.step(self.optim)
            self.scaler.update()
        else:
            output = self.model(image )

            features = self.model.image_encoder(image.type(self.model.dtype))
            features = features / features.norm(dim=-1, keepdim=True)
            fc = self.model.prompt_learner() # fc
            
            img_norm = F.normalize(features, dim=1)  # [batch_size, 512]
            text_norm = F.normalize(fc, dim=1)  # [batch_size, 10, 512]
        
            logits = self.model.logit_scale.exp() * img_norm @ text_norm.t()
            
            isda_aug_y = criterion(k ,self._known_classes , self._total_classes ,features , logits , fc , label , ratio)
            # loss = F.cross_entropy(logits, label)

            self.model_backward_and_update(loss)

        
        loss_summary = {
            "loss": loss.item(),
            "acc": compute_accuracy(logits, label)[0].item(),
        }

        if (self.batch_idx + 1) == self.num_batches:
            self.update_lr()

        return loss_summary

    def parse_batch_train(self, batch):
        input = batch["img"]
        label = batch["label"]
        input = input.to(self.device)
        label = label.to(self.device)
        return input, label

    def load_model(self, directory, epoch=None):
        if not directory:
            print("Note that load_model() is skipped as no pretrained model is given")
            return

        names = self.get_model_names() # ['prompt_learner']
        
        # By default, the best model is loaded
        model_file = "model-best.pth.tar"

        if epoch is not None:
            model_file = "model.pth.tar-" + str(epoch)

        for name in names:
            model_path = osp.join(directory, name, model_file)

            if not osp.exists(model_path):
                raise FileNotFoundError('Model not found at "{}"'.format(model_path))

            checkpoint = load_checkpoint(model_path)
            '''
            ctx
            token_prefix
            token_suffix
            epoch
            学习器等参数
            '''
            state_dict = checkpoint["state_dict"]
            epoch = checkpoint["epoch"]

            # Ignore fixed token vectors
            if "token_prefix" in state_dict:
                del state_dict["token_prefix"]

            if "token_suffix" in state_dict:
                del state_dict["token_suffix"]

            print("Loading weights to {} " 'from "{}" (epoch = {})'.format(name, model_path, epoch))
            # set strict=False
            
            self._models[name].load_state_dict(state_dict, strict=False)
    
    def load_ctx(self , directory , epoch = None):
        model_path = directory

        if not osp.exists(model_path):
            raise FileNotFoundError('Model not found at "{}"'.format(model_path))

        checkpoint = load_checkpoint(model_path)
        
        # ctx , token_prefix , token_suffix , epoch , 学习器等参数
        state_dict = checkpoint["state_dict"]
        epoch = checkpoint["epoch"]

        if "token_prefix" in state_dict:
            del state_dict["token_prefix"]
        if "token_suffix" in state_dict:
            del state_dict["token_suffix"]
            # set strict=False
        
        return state_dict
    
    

    def _extract_vectors(self, loader):
        self.model.eval()
        vectors, targets = [], []
        with torch.no_grad():
            for _, batch in enumerate(loader):
                # print(len(vectors) ,batch['label'])
                _inputs, _targets = self.parse_batch_train(batch)
                
                _targets = _targets.cpu().numpy()
                if isinstance(self.model, nn.DataParallel):
                    _vectors = tensor2numpy( self.encode_image(_inputs.to(self.device)))
                else:
                    _vectors = tensor2numpy( self.encode_image(_inputs.to(self.device)) )
                vectors.append(_vectors)
                targets.append(_targets)

        return np.concatenate(vectors), np.concatenate(targets)
    
    def _reduce_exemplar(self, data_manager, m):
        print("Reducing exemplars...({} per classes)".format(m))
        dummy_data, dummy_targets = copy.deepcopy(self._data_memory), copy.deepcopy(
            self._targets_memory
        )
        self._class_means = np.zeros((self._total_classes, self.feature_dim))
        self._data_memory, self._targets_memory = np.array([]), np.array([])
        for class_idx in range(self._known_classes):
            mask = np.where(dummy_targets == class_idx)[0]
            dd, dt = dummy_data[mask][:m], dummy_targets[mask][:m]
            self._data_memory = (
                np.concatenate((self._data_memory, dd))
                if len(self._data_memory) != 0
                else dd
            )
            self._targets_memory = (
                np.concatenate((self._targets_memory, dt))
                if len(self._targets_memory) != 0
                else dt
            )

            # Exemplar mean
            data , _ = data_manager.get_dataset(
                [], source="train", mode="test", appendent=(dd, dt)
            )

            train_loader = build_data_loader(self.cfg,
                            sampler_type=self.cfg.DATALOADER.TEST.SAMPLER, # 采样类型  train : RandomSampler  test : SequentialSampler
                            data_source=data,
                            batch_size= 100 ,
                            tfm= data_manager.tfm_test,
                            is_train=False,
                            dataset_wrapper=self.data_manager.dataset_wrapper)
                        
            vectors, _ = self._extract_vectors(train_loader)
            vectors = (vectors.T / (np.linalg.norm(vectors.T, axis=0) + EPSILON)).T
            mean = np.mean(vectors, axis=0)
            mean = mean / np.linalg.norm(mean)

            self._class_means[class_idx, :] = mean

    def _construct_exemplar(self, data_manager, m):
        print("Constructing exemplars...({} per classes)".format(m))
        temp = m
        for class_idx in range(self._known_classes, self._total_classes):
            # print(class_idx)
            m = temp
            data, targets = data_manager.get_dataset(
                np.arange(class_idx, class_idx + 1),
                source="train",
                mode="test",
                ret_data=False,
            )
            
            train_loader = build_data_loader(self.cfg,
                            sampler_type=self.cfg.DATALOADER.TEST.SAMPLER, # 采样类型  train : RandomSampler  test : SequentialSampler
                            data_source=data,
                            batch_size=64 , # cfg.DATALOADER.TRAIN_X.BATCH_SIZE, # train : 32 test : 100
                            n_domain=self.cfg.DATALOADER.TRAIN_X.N_DOMAIN,
                            n_ins=self.cfg.DATALOADER.TRAIN_X.N_INS,
                            tfm= data_manager.tfm_test,
                            is_train=False,
                            dataset_wrapper=self.data_manager.dataset_wrapper)
            
            vectors, _ = self._extract_vectors(train_loader)

            vectors = (vectors.T / (np.linalg.norm(vectors.T, axis=0) + EPSILON)).T
            class_mean = np.mean(vectors, axis=0) # 类均值
            
            # Select
            selected_exemplars = []
            exemplar_vectors = []  # [n, feature_dim]
            if len(vectors) < m:
                m = len(vectors)
            for k in range(1, m + 1):
                S = np.sum(
                    exemplar_vectors, axis=0
                )  # [feature_dim] sum of selected exemplars vectors
                mu_p = (vectors + S) / k  # [n, feature_dim] sum to all vectors
                
                i = np.argmin(np.sqrt(np.sum((class_mean - mu_p) ** 2, axis=1)))
                selected_exemplars.append(
                    np.array(data)[i]
                )  # New object to avoid passing by inference
                exemplar_vectors.append(
                    np.array(vectors)[i]
                )  # New object to avoid passing by inference

                vectors = np.delete(
                    vectors, i, axis=0
                )  # Remove it to avoid duplicative selection
                data = np.delete(
                    data, i, axis=0
                )  # Remove it to avoid duplicative selection

            # uniques = np.unique(selected_exemplars, axis=0)
            # print('Unique elements: {}'.format(len(uniques)))
            selected_exemplars = np.array(selected_exemplars)
            exemplar_targets = np.full(m, class_idx)
            self._data_memory = (
                np.concatenate((self._data_memory, selected_exemplars))
                if len(self._data_memory) != 0
                else selected_exemplars
            )
            self._targets_memory = (
                np.concatenate((self._targets_memory, exemplar_targets))
                if len(self._targets_memory) != 0
                else exemplar_targets
            )
            # Exemplar mean
            data , _ = data_manager.get_dataset(
                [],
                source="train",
                mode="test",
                appendent=(selected_exemplars, exemplar_targets),
            )
            # print(len(selected_exemplars))
            train_loader = build_data_loader(self.cfg,
                            sampler_type=self.cfg.DATALOADER.TEST.SAMPLER, # 采样类型  train : RandomSampler  test : SequentialSampler
                            data_source=data,
                            batch_size=64 , # cfg.DATALOADER.TRAIN_X.BATCH_SIZE, # train : 32 test : 100
                            n_domain=self.cfg.DATALOADER.TRAIN_X.N_DOMAIN,
                            n_ins=self.cfg.DATALOADER.TRAIN_X.N_INS,
                            tfm= data_manager.tfm_test,
                            is_train=False,
                            dataset_wrapper=self.data_manager.dataset_wrapper)
            
            vectors, _ = self._extract_vectors(train_loader)
            vectors = (vectors.T / (np.linalg.norm(vectors.T, axis=0) + EPSILON)).T
            mean = np.mean(vectors, axis=0)
            mean = mean / np.linalg.norm(mean)

            self._class_means[class_idx, :] = mean


    def extract_vectors(self, loader):
        self.model.eval()
        vectors, targets = [], []
        with torch.no_grad():
            for _, batch in enumerate(loader):
                # print(len(vectors) ,batch['label'])
                _inputs, _targets = self.parse_batch_train(batch)
                
                _targets = _targets.cpu().numpy()
                if isinstance(self.model, nn.DataParallel):
                    _vectors = tensor2numpy( self.encode_image(_inputs.to(self.device)))
                else:
                    _vectors = tensor2numpy( self.encode_image(_inputs.to(self.device)))
                vectors.append(_vectors)
                targets.append(_targets)

        return np.concatenate(vectors), np.concatenate(targets)

              

    def _get_memory(self):
        if len(self._data_memory) == 0:
            return None
        else:
            return (self._data_memory, self._targets_memory)

    def to_var(self , x, requires_grad=True):
        if torch.cuda.is_available():
            x = x.to(self.device)
        return Variable(x, requires_grad=requires_grad)

    def get_feature_mean(self , imbalanced_train_loader ):
        self.model.eval()
        cls_num_list = self.cls_num_list
        cls_num = len(cls_num_list)
        i = 0 
        feature_mean_end=torch.zeros(cls_num , 512)
        with torch.no_grad():
            for self.batch_idx , batch in enumerate(imbalanced_train_loader):
                input, target = self.parse_batch_train(batch)
                target = target.to(self.device)
                input = input.to(self.device)
                input_var = self.to_var(input, requires_grad=False)

                features, fused_text, contrastive_loss = self.model.fusion(input_var , target)
                # similarity = self.model.featurefusion.compute_similarity(fused_img, fused_text , self.model.logit_scale.exp())
                features = features.detach()
                features = features.cpu().data.numpy()
                
                for out, label in zip(features, target):
                    feature_mean_end[label]= feature_mean_end[label]+out
            img_num_list_tensor=torch.tensor(cls_num_list).unsqueeze(1)
            feature_mean_end=torch.div(feature_mean_end,img_num_list_tensor).detach()     
            
            # print(feature_mean_end.shape)
        return feature_mean_end
    

def _beta(beta , a):
    return 1 - np.power(beta, a)



